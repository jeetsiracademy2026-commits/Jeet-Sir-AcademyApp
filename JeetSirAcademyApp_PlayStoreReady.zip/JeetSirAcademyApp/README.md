# Jeet Sir Academy – Android App

यह Android Studio project **Jeet Sir Academy** के educational app prototype के लिए है।

## अभी उपलब्ध
- Home dashboard
- Courses
- Course detail + lecture list
- Video lecture placeholder
- PDF notes button placeholder
- MCQ practice
- Result screen
- Profile
- Bottom navigation

## Play Store के लिए current configuration
- Application ID: `com.jeetsiracademy.app`
- Version: `1.0.0`
- Target SDK: Android 16 / API 36
- Min SDK: 24
- Release format: Android App Bundle (`.aab`)

## Android Studio में चलाना
1. ZIP extract करें।
2. Android Studio → **Open** → `JeetSirAcademyApp` folder चुनें।
3. SDK Manager में Android 16 (API 36) SDK installed रखें।
4. Gradle sync पूरा होने दें।
5. Emulator या USB debugging वाले Android phone पर **Run** दबाएँ।
6. Play Store release के लिए: **Build → Generate Signed Bundle / APK → Android App Bundle** चुनें।

## Production से पहले जोड़ना बाकी है
- Student login / signup
- Firebase/backend
- Real YouTube/video player integration
- Real PDF storage/download
- Online MCQ database and result storage
- Push notifications
- Admin panel
- Payment/subscription (यदि paid courses रखने हैं)
- Privacy policy URL और Data Safety declaration
- Store screenshots, app icon, feature graphic और final store listing

## Important
Play Store पर पहली public release से पहले Google Play Console में testing/review requirements पूरी करनी होंगी।

यह project अभी educational UI/prototype है; real student accounts और cloud content के लिए backend जोड़ना आवश्यक है।

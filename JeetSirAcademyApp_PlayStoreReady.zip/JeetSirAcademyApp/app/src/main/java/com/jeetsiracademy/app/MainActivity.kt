package com.jeetsiracademy.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.*

private val Blue = Color(0xFF1557D6)
private val LightBlue = Color(0xFFEAF2FF)
private val Green = Color(0xFF16A34A)
private val Bg = Color(0xFFF7F9FC)

class MainActivity : ComponentActivity() { override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { AcademyApp() } } }

@Composable fun AcademyApp() {
    MaterialTheme(colorScheme = lightColorScheme(primary=Blue, background=Bg)) {
        val nav = rememberNavController()
        NavHost(nav, startDestination="home") {
            composable("home") { Home(nav) }; composable("courses") { Courses(nav) }; composable("tests") { Tests(nav) }
            composable("profile") { Profile(nav) }; composable("course/{id}") { Course(nav) }; composable("lecture") { Lecture(nav) }
            composable("test") { TestScreen(nav) }; composable("result/{score}") { Result(nav) }
        }
    }
}

@Composable fun Shell(title:String, nav:NavHostController, selected:Int, content:@Composable ColumnScope.()->Unit) {
    Scaffold(topBar={ TopAppBar(title={Text(title,fontWeight=FontWeight.Bold)})}, bottomBar={
        NavigationBar { listOf("home" to Icons.Default.Home,"courses" to Icons.Default.MenuBook,"tests" to Icons.Default.Quiz,"profile" to Icons.Default.Person).forEachIndexed { i,(route,icon)-> NavigationBarItem(selected=i==selected,onClick={nav.navigate(route){launchSingleTop=true}},icon={Icon(icon,null)},label={Text(listOf("Home","Courses","Tests","Profile")[i])}) } }
    }) { p -> Column(Modifier.padding(p).fillMaxSize().background(Bg), content=content) }
}

@Composable fun Home(nav:NavHostController) { Shell("Jeet Sir Academy",nav,0) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { Text("नमस्ते, Jitendra Sir 👋",fontSize=22.sp,fontWeight=FontWeight.Bold); Text("आज की पढ़ाई शुरू करें",color=Color.Gray) }
        item { Card(colors=CardDefaults.cardColors(containerColor=Blue),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(18.dp)){Text("UP PGT Geography 2026",color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Bold);Text("NCERT Class 11 • 37% complete",color=Color.White.copy(.9f),modifier=Modifier.padding(vertical=8.dp));Button(onClick={nav.navigate("course/geo")},colors=ButtonDefaults.buttonColors(containerColor=Color.White,contentColor=Blue)){Text("Continue Learning")}}} }
        item { Text("Quick Practice",fontSize=18.sp,fontWeight=FontWeight.Bold) }
        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ ActionCard("Daily MCQ","20 Questions",Icons.Default.Quiz){nav.navigate("test")}; ActionCard("Mock Test","UPSSSC PET",Icons.Default.Timer){nav.navigate("test")} } }
        item { Text("Popular Courses",fontSize=18.sp,fontWeight=FontWeight.Bold) }
        item { CourseCard("भूगोल • NCERT Class 11","12 Lectures • 37% complete"){nav.navigate("course/geo")} }
        item { CourseCard("UPSSSC PET 2026 • History","25 Lectures • New"){nav.navigate("course/geo")} }
    }
} }

@Composable fun ActionCard(a:String,b:String,icon:androidx.compose.ui.graphics.vector.ImageVector,onClick:()->Unit){ Card(Modifier.weight(1f).clickable(onClick=onClick),shape=RoundedCornerShape(14.dp)){Column(Modifier.padding(14.dp)){Icon(icon,null,tint=Blue);Text(a,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp));Text(b,color=Color.Gray,fontSize=12.sp)}} }
@Composable fun CourseCard(title:String,sub:String,onClick:()->Unit){ Card(Modifier.fillMaxWidth().clickable(onClick=onClick),shape=RoundedCornerShape(14.dp)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(54.dp).background(LightBlue,RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.School,null,tint=Blue)};Column(Modifier.padding(start=12.dp).weight(1f)){Text(title,fontWeight=FontWeight.Bold);Text(sub,color=Color.Gray,fontSize=13.sp)};Icon(Icons.Default.ChevronRight,null)}} }

@Composable fun Courses(nav:NavHostController){Shell("Courses",nav,1){LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("All Courses",fontSize=22.sp,fontWeight=FontWeight.Bold)};items(listOf("Geography • NCERT Class 6–12","History • Complete Modern History","Polity • Indian Constitution","UP Special • GK & Current Affairs")){x->CourseCard(x,"Complete course • Video + Notes + MCQ"){nav.navigate("course/geo")}}}}}
@Composable fun Tests(nav:NavHostController){Shell("Tests",nav,2){LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("Practice & Mock Tests",fontSize=22.sp,fontWeight=FontWeight.Bold)};items(listOf("Daily MCQ Challenge","UPSSSC PET 2026 • Mock Test 01","UP PGT Geography • Practice Set","CTET Social Science • Mock Test")){x->Card(Modifier.fillMaxWidth().clickable{nav.navigate("test")}){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Quiz,null,tint=Blue);Column(Modifier.padding(start=12.dp)){Text(x,fontWeight=FontWeight.Bold);Text("20 Questions • Timer",color=Color.Gray,fontSize=13.sp)}}}}}}}
@Composable fun Profile(nav:NavHostController){Shell("Profile",nav,3){Column(Modifier.padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){Box(Modifier.size(90.dp).background(LightBlue,RoundedCornerShape(45.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.Person,null,tint=Blue,modifier=Modifier.size(48.dp))};Text("Jitendra Sir",fontSize=22.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp));Text("Jeet Sir Academy",color=Color.Gray);Spacer(Modifier.height(24.dp));listOf("My Courses","Continue Learning","Test History","Certificates","Settings").forEach{Text(it,fontSize=17.sp,modifier=Modifier.fillMaxWidth().clickable{}.padding(16.dp))}}}}

@Composable fun Course(nav:NavHostController){Shell("भूगोल • NCERT Class 11",nav,1){LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Card(colors=CardDefaults.cardColors(containerColor=LightBlue)){Column(Modifier.padding(16.dp)){Text("भूगोल एक विषय के रूप में",fontSize=20.sp,fontWeight=FontWeight.Bold);Text("37% Complete",color=Blue);LinearProgressIndicator(progress={.37f},modifier=Modifier.fillMaxWidth().padding(vertical=12.dp))}}};item{Text("Lectures",fontSize=19.sp,fontWeight=FontWeight.Bold)};items((1..8).toList()){n->Card(Modifier.fillMaxWidth().clickable{nav.navigate("lecture")}){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text("$n",fontWeight=FontWeight.Bold,color=Blue);Column(Modifier.padding(start=14.dp)){Text("Lecture $n • Geography",fontWeight=FontWeight.Bold);Text("Video • Notes • MCQ",color=Color.Gray,fontSize=12.sp)}}}}}}}

@Composable fun Lecture(nav:NavHostController){Shell("Lecture 1",nav,1){Column(Modifier.padding(16.dp)){Box(Modifier.fillMaxWidth().height(210.dp).background(Color(0xFF172033),RoundedCornerShape(16.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.PlayCircle,null,tint=Color.White,modifier=Modifier.size(64.dp))};Text("भूगोल एक विषय के रूप में",fontSize=21.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=16.dp));Text("NCERT Class 11 • Lecture 1",color=Color.Gray);Spacer(Modifier.height(18.dp));Button(onClick={nav.navigate("test")},modifier=Modifier.fillMaxWidth()){Text("Start MCQ Practice")};OutlinedButton(onClick={},modifier=Modifier.fillMaxWidth().padding(top=8.dp)){Text("Download PDF Notes")}}}

@Composable fun TestScreen(nav:NavHostController){var q by remember{mutableIntStateOf(0)};var selected by remember{mutableStateOf<Int?>(null)};val qs=listOf("भारत का सबसे बड़ा भौगोलिक प्रदेश कौन-सा है?","पृथ्वी की परिक्रमण अवधि लगभग कितनी है?","भारतीय संविधान का संरक्षक किसे माना जाता है?");val opts=listOf(listOf("हिमालय","उत्तरी मैदान","प्रायद्वीपीय पठार","तटीय मैदान"),listOf("24 घंटे","365¼ दिन","30 दिन","12 घंटे"),listOf("संसद","सर्वोच्च न्यायालय","राष्ट्रपति","मंत्रिपरिषद"));Column(Modifier.fillMaxSize().padding(20.dp)){Text("Daily MCQ Challenge",fontSize=22.sp,fontWeight=FontWeight.Bold);Text("Question ${q+1} of ${qs.size}",color=Color.Gray,modifier=Modifier.padding(vertical=10.dp));Text(qs[q],fontSize=19.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(bottom=16.dp));opts[q].forEachIndexed{i,o->Card(Modifier.fillMaxWidth().padding(vertical=5.dp).clickable{selected=i},colors=CardDefaults.cardColors(containerColor=if(selected==i)LightBlue else Color.White)){Text(o,Modifier.padding(16.dp),fontWeight=if(selected==i)FontWeight.Bold else FontWeight.Normal)}};Spacer(Modifier.weight(1f));Button(onClick={if(q<qs.lastIndex){q++;selected=null}else nav.navigate("result/3")},modifier=Modifier.fillMaxWidth()){Text(if(q<qs.lastIndex)"Next Question" else "Submit Test")}}}
@Composable fun Result(nav:NavHostController){Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(Icons.Default.EmojiEvents,null,tint=Green,modifier=Modifier.size(72.dp));Text("Test Completed!",fontSize=26.sp,fontWeight=FontWeight.Bold);Text("Your Score",color=Color.Gray,modifier=Modifier.padding(top=12.dp));Text("3 / 3",fontSize=42.sp,fontWeight=FontWeight.Bold,color=Blue);Button(onClick={nav.navigate("home"){popUpTo("home")}},modifier=Modifier.fillMaxWidth().padding(top=24.dp)){Text("Back to Home")}}}
